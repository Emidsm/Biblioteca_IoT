--
-- PostgreSQL database dump
--

\restrict GDEKqOVjhqcoeWQpI4Oeg6D9W0mpAdUnQvgbw6bbzcMQvVacmAg5W0V5ZzuLYBA

-- Dumped from database version 15.18
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: admin_biblioteca
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    tipo character varying(50) NOT NULL,
    origen character varying(50) DEFAULT 'sistema'::character varying NOT NULL,
    usuario_id integer,
    ejemplar_id integer,
    mensaje text NOT NULL,
    payload_raw text
);


ALTER TABLE public.audit_log OWNER TO admin_biblioteca;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: admin_biblioteca
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_log_id_seq OWNER TO admin_biblioteca;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin_biblioteca
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: ejemplares; Type: TABLE; Schema: public; Owner: admin_biblioteca
--

CREATE TABLE public.ejemplares (
    id integer NOT NULL,
    libro_id integer NOT NULL,
    codigo_barras character varying(50),
    estado character varying(50) DEFAULT 'disponible'::character varying NOT NULL,
    condicion character varying(50) DEFAULT 'bueno'::character varying NOT NULL,
    fecha_adquisicion date,
    notas text,
    CONSTRAINT ejemplares_condicion_check CHECK (((condicion)::text = ANY ((ARRAY['nuevo'::character varying, 'bueno'::character varying, 'regular'::character varying, 'deteriorado'::character varying])::text[]))),
    CONSTRAINT ejemplares_estado_check CHECK (((estado)::text = ANY ((ARRAY['disponible'::character varying, 'prestado'::character varying, 'reservado'::character varying, 'mantenimiento'::character varying, 'baja'::character varying])::text[])))
);


ALTER TABLE public.ejemplares OWNER TO admin_biblioteca;

--
-- Name: ejemplares_id_seq; Type: SEQUENCE; Schema: public; Owner: admin_biblioteca
--

CREATE SEQUENCE public.ejemplares_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ejemplares_id_seq OWNER TO admin_biblioteca;

--
-- Name: ejemplares_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin_biblioteca
--

ALTER SEQUENCE public.ejemplares_id_seq OWNED BY public.ejemplares.id;


--
-- Name: libros; Type: TABLE; Schema: public; Owner: admin_biblioteca
--

CREATE TABLE public.libros (
    id integer NOT NULL,
    isbn character varying(50),
    titulo character varying(255) NOT NULL,
    autor character varying(255) NOT NULL,
    editorial character varying(255),
    anio_publicacion integer,
    genero character varying(100),
    descripcion text,
    qr_codigo character varying(50) NOT NULL,
    imagen_url text,
    ubicacion character varying(100),
    activo smallint DEFAULT 1 NOT NULL,
    fecha_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT libros_activo_check CHECK ((activo = ANY (ARRAY[0, 1])))
);


ALTER TABLE public.libros OWNER TO admin_biblioteca;

--
-- Name: prestamos; Type: TABLE; Schema: public; Owner: admin_biblioteca
--

CREATE TABLE public.prestamos (
    id integer NOT NULL,
    usuario_id integer NOT NULL,
    ejemplar_id integer NOT NULL,
    fecha_prestamo timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    fecha_devolucion_esperada timestamp without time zone NOT NULL,
    fecha_devolucion_real timestamp without time zone,
    estado character varying(50) DEFAULT 'activo'::character varying NOT NULL,
    rfid_prestamo character varying(50),
    qr_prestamo character varying(50),
    rfid_devolucion character varying(50),
    notas text,
    CONSTRAINT prestamos_estado_check CHECK (((estado)::text = ANY ((ARRAY['activo'::character varying, 'devuelto'::character varying, 'vencido'::character varying, 'perdido'::character varying])::text[])))
);


ALTER TABLE public.prestamos OWNER TO admin_biblioteca;

--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: admin_biblioteca
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    apellido character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    telefono character varying(50),
    rfid_tag character varying(50),
    tipo_usuario character varying(50) DEFAULT 'estudiante'::character varying NOT NULL,
    activo smallint DEFAULT 1 NOT NULL,
    max_prestamos integer DEFAULT 3 NOT NULL,
    fecha_registro timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    fecha_vigencia timestamp without time zone,
    notas text,
    CONSTRAINT usuarios_activo_check CHECK ((activo = ANY (ARRAY[0, 1]))),
    CONSTRAINT usuarios_tipo_usuario_check CHECK (((tipo_usuario)::text = ANY ((ARRAY['estudiante'::character varying, 'docente'::character varying, 'administrativo'::character varying, 'externo'::character varying])::text[])))
);


ALTER TABLE public.usuarios OWNER TO admin_biblioteca;

--
-- Name: estadisticas_dashboard; Type: VIEW; Schema: public; Owner: admin_biblioteca
--

CREATE VIEW public.estadisticas_dashboard AS
 SELECT ( SELECT count(*) AS count
           FROM public.usuarios
          WHERE (usuarios.activo = 1)) AS total_usuarios,
    ( SELECT count(*) AS count
           FROM public.libros
          WHERE (libros.activo = 1)) AS total_libros,
    ( SELECT count(*) AS count
           FROM public.ejemplares
          WHERE ((ejemplares.estado)::text = 'disponible'::text)) AS ejemplares_disponibles,
    ( SELECT count(*) AS count
           FROM public.ejemplares
          WHERE ((ejemplares.estado)::text = 'prestado'::text)) AS ejemplares_prestados,
    ( SELECT count(*) AS count
           FROM public.prestamos
          WHERE ((prestamos.estado)::text = 'activo'::text)) AS prestamos_activos,
    ( SELECT count(*) AS count
           FROM public.prestamos
          WHERE (((prestamos.estado)::text = 'activo'::text) AND (prestamos.fecha_devolucion_esperada < CURRENT_TIMESTAMP))) AS prestamos_vencidos;


ALTER VIEW public.estadisticas_dashboard OWNER TO admin_biblioteca;

--
-- Name: libros_id_seq; Type: SEQUENCE; Schema: public; Owner: admin_biblioteca
--

CREATE SEQUENCE public.libros_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.libros_id_seq OWNER TO admin_biblioteca;

--
-- Name: libros_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin_biblioteca
--

ALTER SEQUENCE public.libros_id_seq OWNED BY public.libros.id;


--
-- Name: prestamos_activos; Type: VIEW; Schema: public; Owner: admin_biblioteca
--

CREATE VIEW public.prestamos_activos AS
 SELECT p.id AS prestamo_id,
    (((u.nombre)::text || ' '::text) || (u.apellido)::text) AS usuario_nombre,
    u.rfid_tag,
    u.email,
    l.titulo,
    l.autor,
    l.qr_codigo,
    e.id AS ejemplar_id,
    e.codigo_barras,
    p.fecha_prestamo,
    p.fecha_devolucion_esperada,
        CASE
            WHEN (p.fecha_devolucion_esperada < CURRENT_TIMESTAMP) THEN 1
            ELSE 0
        END AS vencido
   FROM (((public.prestamos p
     JOIN public.usuarios u ON ((p.usuario_id = u.id)))
     JOIN public.ejemplares e ON ((p.ejemplar_id = e.id)))
     JOIN public.libros l ON ((e.libro_id = l.id)))
  WHERE ((p.estado)::text = 'activo'::text);


ALTER VIEW public.prestamos_activos OWNER TO admin_biblioteca;

--
-- Name: prestamos_id_seq; Type: SEQUENCE; Schema: public; Owner: admin_biblioteca
--

CREATE SEQUENCE public.prestamos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.prestamos_id_seq OWNER TO admin_biblioteca;

--
-- Name: prestamos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin_biblioteca
--

ALTER SEQUENCE public.prestamos_id_seq OWNED BY public.prestamos.id;


--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: admin_biblioteca
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.usuarios_id_seq OWNER TO admin_biblioteca;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin_biblioteca
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: admin_biblioteca
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: ejemplares id; Type: DEFAULT; Schema: public; Owner: admin_biblioteca
--

ALTER TABLE ONLY public.ejemplares ALTER COLUMN id SET DEFAULT nextval('public.ejemplares_id_seq'::regclass);


--
-- Name: libros id; Type: DEFAULT; Schema: public; Owner: admin_biblioteca
--

ALTER TABLE ONLY public.libros ALTER COLUMN id SET DEFAULT nextval('public.libros_id_seq'::regclass);


--
-- Name: prestamos id; Type: DEFAULT; Schema: public; Owner: admin_biblioteca
--

ALTER TABLE ONLY public.prestamos ALTER COLUMN id SET DEFAULT nextval('public.prestamos_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: admin_biblioteca
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: admin_biblioteca
--

COPY public.audit_log (id, "timestamp", tipo, origen, usuario_id, ejemplar_id, mensaje, payload_raw) FROM stdin;
1	2026-05-31 14:49:52.396624	backup	sistema	\N	\N	Respaldo inicial del sistema completado.	\N
2	2026-05-31 14:49:52.396624	login	api	\N	\N	Sistema IoT iniciado correctamente.	\N
\.


--
-- Data for Name: ejemplares; Type: TABLE DATA; Schema: public; Owner: admin_biblioteca
--

COPY public.ejemplares (id, libro_id, codigo_barras, estado, condicion, fecha_adquisicion, notas) FROM stdin;
1	1	EJ-001-A	disponible	bueno	2021-03-15	\N
2	1	EJ-001-B	prestado	bueno	2021-03-15	\N
3	1	EJ-001-C	disponible	regular	2019-08-20	\N
4	2	EJ-002-A	disponible	nuevo	2023-01-10	\N
5	2	EJ-002-B	mantenimiento	deteriorado	2018-05-05	\N
6	3	EJ-003-A	prestado	bueno	2022-09-01	\N
7	3	EJ-003-B	disponible	nuevo	2023-11-20	\N
8	4	EJ-004-A	disponible	bueno	2020-06-15	\N
9	4	EJ-004-B	disponible	regular	2017-03-22	\N
10	4	EJ-004-C	prestado	bueno	2022-01-08	\N
11	5	EJ-005-A	disponible	bueno	2021-07-30	\N
12	6	EJ-006-A	disponible	regular	2015-04-10	\N
13	6	EJ-006-B	prestado	deteriorado	2010-11-25	\N
14	7	EJ-007-A	disponible	bueno	2022-02-14	\N
15	8	EJ-008-A	disponible	bueno	2020-08-01	\N
16	8	EJ-008-B	prestado	regular	2020-08-01	\N
17	8	EJ-008-C	disponible	nuevo	2024-01-15	\N
18	9	EJ-009-A	disponible	regular	2019-08-15	\N
19	9	EJ-009-B	disponible	bueno	2022-08-15	\N
20	10	EJ-010-A	disponible	nuevo	2023-05-01	\N
21	11	EJ-011-A	disponible	nuevo	2023-05-01	\N
22	12	EJ-012-A	prestado	bueno	2022-11-10	\N
23	13	EJ-013-A	disponible	regular	2018-03-20	\N
24	14	EJ-014-A	disponible	bueno	2021-09-05	\N
25	15	EJ-015-A	disponible	bueno	2023-03-12	\N
\.


--
-- Data for Name: libros; Type: TABLE DATA; Schema: public; Owner: admin_biblioteca
--

COPY public.libros (id, isbn, titulo, autor, editorial, anio_publicacion, genero, descripcion, qr_codigo, imagen_url, ubicacion, activo, fecha_alta) FROM stdin;
1	978-0-13-468599-1	Clean Code	Robert C. Martin	Prentice Hall	2008	Programación	Guía para escribir código limpio y mantenible.	LIB-00001	\N	A1-01	1	2026-05-31 14:49:52.383023
2	978-0-201-63361-0	Design Patterns	Gang of Four	Addison-Wesley	1994	Programación	Los 23 patrones de diseño clásicos de software.	LIB-00002	\N	A1-02	1	2026-05-31 14:49:52.383023
3	978-0-13-235088-4	The Pragmatic Programmer	David Thomas, Andrew Hunt	Addison-Wesley	2019	Programación	De aprendiz a maestro en desarrollo de software.	LIB-00003	\N	A1-03	1	2026-05-31 14:49:52.383023
4	978-607-438-458-1	Cien años de soledad	Gabriel García Márquez	Editorial Sudamericana	1967	Literatura	Obra cumbre del realismo mágico latinoamericano.	LIB-00004	\N	B2-01	1	2026-05-31 14:49:52.383023
5	978-84-233-3633-4	El nombre de la rosa	Umberto Eco	Lumen	1980	Novela histórica	Investigación de una serie de muertes en una abadía medieval.	LIB-00005	\N	B2-02	1	2026-05-31 14:49:52.383023
6	978-0-13-110362-7	The C Programming Language	Brian Kernighan, Dennis Ritchie	Prentice Hall	1988	Programación	El libro definitivo del lenguaje C.	LIB-00006	\N	A1-04	1	2026-05-31 14:49:52.383023
7	978-0-596-51774-8	JavaScript: The Good Parts	Douglas Crockford	O'Reilly Media	2008	Programación	Las partes esenciales y elegantes de JavaScript.	LIB-00007	\N	A1-05	1	2026-05-31 14:49:52.383023
8	978-607-07-3823-5	Física universitaria vol. 1	Hugh Young, Roger Freedman	Pearson	2013	Ciencias	Mecánica, termodinámica y ondas para ingeniería.	LIB-00008	\N	C3-01	1	2026-05-31 14:49:52.383023
9	978-970-26-0991-7	Cálculo de una variable	James Stewart	Cengage Learning	2008	Matemáticas	Límites, derivadas e integrales de una variable.	LIB-00009	\N	C3-02	1	2026-05-31 14:49:52.383023
10	978-0-321-12521-7	Domain-Driven Design	Eric Evans	Addison-Wesley	2003	Programación	Cómo modelar software complejo con DDD.	LIB-00010	\N	A1-06	1	2026-05-31 14:49:52.383023
11	978-0-13-792025-5	Artificial Intelligence: A Modern Approach	Stuart Russell, Peter Norvig	Pearson	2020	IA/ML	El texto de referencia más completo sobre Inteligencia Artificial.	LIB-00011	\N	A2-01	1	2026-05-31 14:49:52.383023
12	978-1-491-95229-7	Hands-On Machine Learning with Scikit-Learn	Aurélien Géron	O'Reilly Media	2019	IA/ML	ML práctico con Python, Scikit-Learn y TensorFlow.	LIB-00012	\N	A2-02	1	2026-05-31 14:49:52.383023
13	978-607-17-0736-5	Introducción a los sistemas de bases de datos	C.J. Date	Pearson	2001	Bases de Datos	Fundamentos teóricos y prácticos de bases de datos relacionales.	LIB-00013	\N	A3-01	1	2026-05-31 14:49:52.383023
14	978-1-491-91205-8	Learning Python	Mark Lutz	O'Reilly Media	2013	Programación	El manual más completo del lenguaje Python.	LIB-00014	\N	A1-07	1	2026-05-31 14:49:52.383023
15	978-0-13-598128-8	Computer Networks	Andrew Tanenbaum	Pearson	2010	Redes	Fundamentos de redes de computadoras y protocolos.	LIB-00015	\N	A4-01	1	2026-05-31 14:49:52.383023
\.


--
-- Data for Name: prestamos; Type: TABLE DATA; Schema: public; Owner: admin_biblioteca
--

COPY public.prestamos (id, usuario_id, ejemplar_id, fecha_prestamo, fecha_devolucion_esperada, fecha_devolucion_real, estado, rfid_prestamo, qr_prestamo, rfid_devolucion, notas) FROM stdin;
1	1	2	2026-05-26 14:49:52.389602	2026-06-09 14:49:52.389602	\N	activo	A3F2B1C4	LIB-00001	\N	\N
2	3	6	2026-05-29 14:49:52.389602	2026-06-12 14:49:52.389602	\N	activo	C1A5F3B2	LIB-00003	\N	\N
3	4	12	2026-05-23 14:49:52.389602	2026-06-06 14:49:52.389602	\N	activo	D8C6E4A3	LIB-00004	\N	\N
4	6	14	2026-05-28 14:49:52.389602	2026-06-11 14:49:52.389602	\N	activo	F4A1C8B5	LIB-00006	\N	\N
5	8	18	2026-05-21 14:49:52.389602	2026-06-04 14:49:52.389602	\N	activo	B5E8A2D6	LIB-00008	\N	\N
6	11	23	2026-05-16 14:49:52.389602	2026-05-30 14:49:52.389602	\N	activo	E9B2F4D7	LIB-00012	\N	\N
7	2	1	2026-05-01 14:49:52.395063	2026-05-15 14:49:52.395063	2026-05-13 14:49:52.395063	devuelto	B7D4E2F1	LIB-00001	B7D4E2F1	\N
8	5	7	2026-04-16 14:49:52.395063	2026-04-30 14:49:52.395063	2026-04-29 14:49:52.395063	devuelto	E2B7D5C4	LIB-00003	E2B7D5C4	\N
9	7	10	2026-05-11 14:49:52.395063	2026-05-25 14:49:52.395063	2026-05-24 14:49:52.395063	devuelto	A6D3F7E2	LIB-00004	A6D3F7E2	\N
10	9	16	2026-04-01 14:49:52.395063	2026-04-15 14:49:52.395063	2026-04-17 14:49:52.395063	devuelto	C7F1B4A8	LIB-00006	C7F1B4A8	\N
11	12	21	2026-05-17 14:49:52.395063	2026-05-31 14:49:52.395063	2026-05-30 14:49:52.395063	devuelto	F1C5A8E3	LIB-00009	F1C5A8E3	\N
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: admin_biblioteca
--

COPY public.usuarios (id, nombre, apellido, email, telefono, rfid_tag, tipo_usuario, activo, max_prestamos, fecha_registro, fecha_vigencia, notas) FROM stdin;
1	Carlos	Mendoza Rivera	cmendoza@uni.edu.mx	4921234567	A3F2B1C4	estudiante	1	3	2026-05-31 14:49:52.379996	2026-12-31 00:00:00	\N
2	Sofía	Torres Guzmán	storres@uni.edu.mx	4929876543	B7D4E2F1	estudiante	1	3	2026-05-31 14:49:52.379996	2026-12-31 00:00:00	\N
3	Dr. Marco	López Hernández	mlopez@docentes.uni.edu.mx	4923456789	C1A5F3B2	docente	1	5	2026-05-31 14:49:52.379996	\N	\N
4	Ana	Jiménez Castro	ajimenez@uni.edu.mx	4924567890	D8C6E4A3	estudiante	1	3	2026-05-31 14:49:52.379996	2026-06-30 00:00:00	\N
5	Roberto	Flores Martínez	rflores@admin.uni.edu.mx	4925678901	E2B7D5C4	administrativo	1	4	2026-05-31 14:49:52.379996	\N	\N
6	Valentina	Ruiz Sánchez	vruiz@uni.edu.mx	4926789012	F4A1C8B5	estudiante	1	3	2026-05-31 14:49:52.379996	2026-12-31 00:00:00	\N
7	Dra. Laura	García Morales	lgarcia@docentes.uni.edu.mx	4927890123	A6D3F7E2	docente	1	5	2026-05-31 14:49:52.379996	\N	\N
8	Miguel	Hernández Vega	mhernandez@uni.edu.mx	4928901234	B5E8A2D6	estudiante	1	3	2026-05-31 14:49:52.379996	2027-01-15 00:00:00	\N
9	Isabel	Martínez Delgado	imartinez@uni.edu.mx	4920123456	C7F1B4A8	estudiante	1	3	2026-05-31 14:49:52.379996	2026-12-31 00:00:00	\N
10	Luis	Ramírez Ortiz	lramirez@extern.mx	4921357924	D3A9E6C1	externo	1	2	2026-05-31 14:49:52.379996	2025-06-01 00:00:00	\N
11	Paola	Chávez Núñez	pchavez@uni.edu.mx	4922468135	E9B2F4D7	estudiante	1	3	2026-05-31 14:49:52.379996	2026-12-31 00:00:00	\N
12	Javier	Moreno Aguilar	jmoreno@docentes.uni.edu.mx	4923579246	F1C5A8E3	docente	1	5	2026-05-31 14:49:52.379996	\N	\N
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin_biblioteca
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 2, true);


--
-- Name: ejemplares_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin_biblioteca
--

SELECT pg_catalog.setval('public.ejemplares_id_seq', 25, true);


--
-- Name: libros_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin_biblioteca
--

SELECT pg_catalog.setval('public.libros_id_seq', 15, true);


--
-- Name: prestamos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin_biblioteca
--

SELECT pg_catalog.setval('public.prestamos_id_seq', 11, true);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin_biblioteca
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 12, true);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_biblioteca
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: ejemplares ejemplares_codigo_barras_key; Type: CONSTRAINT; Schema: public; Owner: admin_biblioteca
--

ALTER TABLE ONLY public.ejemplares
    ADD CONSTRAINT ejemplares_codigo_barras_key UNIQUE (codigo_barras);


--
-- Name: ejemplares ejemplares_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_biblioteca
--

ALTER TABLE ONLY public.ejemplares
    ADD CONSTRAINT ejemplares_pkey PRIMARY KEY (id);


--
-- Name: libros libros_isbn_key; Type: CONSTRAINT; Schema: public; Owner: admin_biblioteca
--

ALTER TABLE ONLY public.libros
    ADD CONSTRAINT libros_isbn_key UNIQUE (isbn);


--
-- Name: libros libros_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_biblioteca
--

ALTER TABLE ONLY public.libros
    ADD CONSTRAINT libros_pkey PRIMARY KEY (id);


--
-- Name: libros libros_qr_codigo_key; Type: CONSTRAINT; Schema: public; Owner: admin_biblioteca
--

ALTER TABLE ONLY public.libros
    ADD CONSTRAINT libros_qr_codigo_key UNIQUE (qr_codigo);


--
-- Name: prestamos prestamos_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_biblioteca
--

ALTER TABLE ONLY public.prestamos
    ADD CONSTRAINT prestamos_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_email_key; Type: CONSTRAINT; Schema: public; Owner: admin_biblioteca
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_email_key UNIQUE (email);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_biblioteca
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_rfid_tag_key; Type: CONSTRAINT; Schema: public; Owner: admin_biblioteca
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_rfid_tag_key UNIQUE (rfid_tag);


--
-- Name: idx_audit_timestamp; Type: INDEX; Schema: public; Owner: admin_biblioteca
--

CREATE INDEX idx_audit_timestamp ON public.audit_log USING btree ("timestamp");


--
-- Name: idx_ejemplares_estado; Type: INDEX; Schema: public; Owner: admin_biblioteca
--

CREATE INDEX idx_ejemplares_estado ON public.ejemplares USING btree (estado);


--
-- Name: idx_ejemplares_libro; Type: INDEX; Schema: public; Owner: admin_biblioteca
--

CREATE INDEX idx_ejemplares_libro ON public.ejemplares USING btree (libro_id);


--
-- Name: idx_libros_qr; Type: INDEX; Schema: public; Owner: admin_biblioteca
--

CREATE INDEX idx_libros_qr ON public.libros USING btree (qr_codigo);


--
-- Name: idx_prestamos_estado; Type: INDEX; Schema: public; Owner: admin_biblioteca
--

CREATE INDEX idx_prestamos_estado ON public.prestamos USING btree (estado);


--
-- Name: idx_prestamos_usuario; Type: INDEX; Schema: public; Owner: admin_biblioteca
--

CREATE INDEX idx_prestamos_usuario ON public.prestamos USING btree (usuario_id);


--
-- Name: idx_usuarios_rfid; Type: INDEX; Schema: public; Owner: admin_biblioteca
--

CREATE INDEX idx_usuarios_rfid ON public.usuarios USING btree (rfid_tag);


--
-- Name: audit_log audit_log_ejemplar_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin_biblioteca
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_ejemplar_id_fkey FOREIGN KEY (ejemplar_id) REFERENCES public.ejemplares(id);


--
-- Name: audit_log audit_log_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin_biblioteca
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id);


--
-- Name: ejemplares ejemplares_libro_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin_biblioteca
--

ALTER TABLE ONLY public.ejemplares
    ADD CONSTRAINT ejemplares_libro_id_fkey FOREIGN KEY (libro_id) REFERENCES public.libros(id) ON DELETE RESTRICT;


--
-- Name: prestamos prestamos_ejemplar_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin_biblioteca
--

ALTER TABLE ONLY public.prestamos
    ADD CONSTRAINT prestamos_ejemplar_id_fkey FOREIGN KEY (ejemplar_id) REFERENCES public.ejemplares(id) ON DELETE RESTRICT;


--
-- Name: prestamos prestamos_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin_biblioteca
--

ALTER TABLE ONLY public.prestamos
    ADD CONSTRAINT prestamos_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict GDEKqOVjhqcoeWQpI4Oeg6D9W0mpAdUnQvgbw6bbzcMQvVacmAg5W0V5ZzuLYBA

